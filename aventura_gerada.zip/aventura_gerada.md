# Setup Inicial

Excelente! Entendido e pronto para começar. Os parâmetros que você definiu são perfeitos para uma sessão de Vampiro: A Máscara focada no que o sistema faz de melhor.

**Parâmetros da Aventura:**
*   **Sistema:** Vampiro: A Máscara 5ª Edição
*   **Estilo:** Horror Pessoal e Intriga Política
*   **Jogadores:** 3 Neonatos
*   **Duração:** One-shot de ~4 horas

Estou preparado para mergulhar nas sombras e construir este conto de danação e poder com você.

---

### **Passo 1: O Contexto**

Como você sugeriu, o primeiro e mais crucial passo é definir o **Contexto** da nossa aventura. Isso estabelecerá a cidade, a situação política dos Amaldiçoados e o conflito central que irá fisgar os personagens dos jogadores. Um bom contexto é a fundação sobre a qual toda a história será construída.

Para começarmos, proponho três sementes de contexto. Escolha a que mais te intriga, ou podemos misturar elementos delas para criar algo único.

---

#### **Opção 1: "O Banquete Vazio"**
*   **Cidade:** Curitiba, PR. Uma metrópole fria e de planejamento urbano rígido, conhecida como a "Capital Europeia" do Brasil. Para a Camarilla local, a ordem e a discrição são tudo.
*   **Situação Política:** O domínio da Camarilla é antigo e aparentemente estável, governado pela austera Princesa Ventrue, Isolde Reichmann. Contudo, nas últimas semanas, um dos Primógenos mais influentes, um Toreador chamado Valentin Dubois, foi encontrado em seu refúgio, reduzido a cinzas. Um lugar no Conselho Primógeno está vago, e as facções (os tradicionalistas, os reformistas, os ambiciosos) já estão se movendo nas sombras para preenchê-lo.
*   **Conflito Central:** Os personagens, neonatos de diferentes clãs, são "convocados" por seu patrono em comum (talvez o Senescal da cidade ou um Primógeno que os queira usar como peões) para investigar discretamente a morte de Valentin. A ordem oficial é encontrar o culpado, mas a ordem *real* é descobrir podres e segredos dos outros candidatos ao cargo para que o patrono possa manipular a sucessão. O horror pessoal vem da paranoia: quem será o próximo? E o que acontece se o assassino descobrir que está sendo caçado?

#### **Opção 2: "Sangue e Ferrugem"**
*   **Cidade:** Volta Redonda, RJ. A "Cidade do Aço", um domínio historicamente operário e industrial. As noites são preenchidas com o barulho das siderúrgicas e a névoa avermelhada da poluição.
*   **Situação Política:** Este é um Domínio Anarca recém-estabelecido, conquistado da Camarilla há menos de uma década. A liderança é uma aliança frágil entre uma Baronesa Brujah idealista e um Barão Gangrel pragmático. A liberdade é caótica e perigosa. Não há leis rígidas, apenas a reputação e a força bruta.
*   **Conflito Central:** Um novo tipo de "droga de designer" chamada "Ferrugem" está se espalhando pelos mortais da cidade. O problema: o sangue de quem a usa se torna viciante e corrosivo para os vampiros, causando um frenesi de fome incontrolável e degeneração física. A Baronesa Brujah acredita que isso é um ataque da Camarilla para desestabilizar seu domínio. Ela recruta os personagens para se infiltrarem no submundo mortal, descobrirem a origem da Ferrugem e eliminarem a fonte, antes que a cidade inteira se torne um banquete envenenado.

#### **Opção 3: "A Lista do Esquecimento"**
*   **Cidade:** Brasília, DF. O coração do poder mortal no Brasil. Uma cidade de arquitetura modernista, vigilância governamental onipresente e uma sociedade de Amaldiçoados paranoica.
*   **Situação Política:** A cidade não tem um Príncipe ou Barão declarado. É um território neutro e aterrorizado pela Segunda Inquisição. Os vampiros que aqui residem sobrevivem em pequenos coteries isolados, seguindo uma regra de ouro não escrita: não chame atenção. A comunicação é feita por meio de mensagens criptografadas e encontros clandestinos.
*   **Conflito Central:** Um carniçal de longa data, que servia como "bibliotecário" de segredos para vários vampiros da cidade (incluindo os senhores dos personagens), desapareceu. Ele mantinha uma lista – não física, mas em sua memória e em arquivos digitais ocultos – com a localização dos refúgios, identidades mortais e Touchstones de quase todos os Amaldiçoados de Brasília. Os personagens precisam encontrá-lo antes que ele seja capturado pela Segunda Inquisição (a ABIN e a Polícia Federal) ou por outro vampiro que queira a lista para si. Cada noite que passa, o risco de exposição total e extermínio aumenta.

---

Qual dessas opções mais te atrai para a nossa one-shot? Ou talvez você tenha uma ideia diferente que queira misturar com esses elementos?

---

## Contexto

Perfeito. Com base na nossa conversa inicial, decidi expandir a **Opção 1: "O Banquete Vazio"**. Ela se encaixa perfeitamente nos temas de Horror Pessoal e Intriga Política dentro da estrutura clássica da Camarilla, oferecendo um terreno fértil para a desconfiança, ambição e perigo que definem Vampiro: A Máscara.

Aqui estão o Contexto e a Sinopse detalhados para a nossa aventura.

---

### **Título da Aventura:** *Réquiem em Cinzas*

### **Contexto (Background)**

**A Cidade:** Curitiba, a "Capital Modelo". Durante o dia, é uma cidade de parques bem cuidados, planejamento urbano exemplar e um ar de eficiência europeia. À noite, essa ordem se transforma em uma rigidez fria. As ruas largas e bem iluminadas parecem vazias, os parques se tornam poços de escuridão e a arquitetura modernista projeta sombras longas e distorcidas. Para os Amaldiçoados, Curitiba é uma gaiola dourada. A vigilância é constante, e a população mortal, ordeira e discreta, nota qualquer desvio de comportamento. A Máscara aqui não é apenas uma lei, é uma obsessão.

**O Poder Estabelecido:** O domínio é governado com mão de ferro pela **Princesa Isolde Reichmann**, uma Ventrue de linhagem alemã cuja família mortal ajudou a colonizar a região. Ela está no poder há quase um século e valoriza a tradição, a estabilidade e, acima de tudo, o controle. Seu governo é eficiente, mas sufocante. Inovação é vista com suspeita e a ambição, com paranoia. O Elysium, sediado no luxuoso e antigo Clube Curitibano, é um campo de batalhas travadas com sorrisos falsos, elogios envenenados e sussurros devastadores.

**O Vácuo de Poder:** Há uma semana, a estabilidade de Isolde foi abalada. **Valentin Dubois**, o Primógeno Toreador, foi encontrado em seu refúgio – um ateliê de luxo no bairro do Batel – destruído. Não havia sinais de luta, nem de fogo. Ele foi simplesmente reduzido a um monte de cinzas em seu próprio sofá de veludo, um copo de cristal ainda na mão petrificada. Valentin era a alma da vida noturna e artística da cidade. Ele era carismático, influente e o único membro do Conselho Primógeno que ousava desafiar abertamente a rigidez da Princesa. Sua morte final criou um vácuo que todos os clãs agora se apressam para preencher, e o medo se espalhou: se um vampiro tão antigo e poderoso pôde ser eliminado de forma tão limpa, ninguém está seguro.

---

### **Sinopse da Aventura**

As noites de Curitiba tornaram-se mais frias desde a morte final do Primógeno Toreador. No Elysium, a dor da perda foi rapidamente substituída pela sede de oportunidade. A cadeira de Valentin Dubois no Conselho Primógeno está vazia, e as facas já estão sendo afiadas nas sombras para a inevitável luta pelo poder.

É neste cenário de paranoia e ambição que vocês, três neonatos recém-chegados à política da cidade, são convocados para uma reunião secreta. Seu anfitrião é **Marius Vinter**, o Senescal Nosferatu da cidade, o braço de informações e operações secretas da Princesa. Escondido em seu refúgio nos túneis sob o Jardim Botânico, ele lhes oferece uma tarefa de importância vital.

**A missão oficial:** Usando a sua relativa insignificância como um manto, vocês devem investigar discretamente a morte de Valentin. A Princesa quer respostas e, mais importante, quer um culpado para fazer de exemplo.

**A missão real:** Marius sabe que uma investigação direta é suicídio. Ele quer que vocês mergulhem na vida noturna de Valentin, interroguem seus associados, explorem seus segredos e, acima de tudo, descubram as fraquezas e os podres dos *outros candidatos* ao cargo de Primógeno. A verdade sobre o assassino é um bônus; a munição política para que Marius (e a Princesa) possam controlar quem irá preencher o vácuo de poder é o prêmio principal.

Vocês terão que navegar por uma teia de mentiras, enfrentar anciões que os veem como meros peões e lutar contra a própria Fome enquanto desvendam segredos que podem derrubar os pilares do poder em Curitiba. Mas cuidado: o assassino ainda está à solta, e se ele perceber que está sendo caçado por um trio de neonatos curiosos, a sua noite pode terminar da mesma forma que a de Valentin – em um monte de cinzas silenciosas.

---

O que você acha? Se este cenário te agrada, nosso próximo passo pode ser detalhar os **Personagens do Mestre (PdMs)** principais: o Senescal que os contratou e os principais suspeitos/candidatos ao cargo de Primógeno.

---

## Ganchos

Ótima escolha. Um bom conjunto de ganchos é essencial para trazer os jogadores para a trama e dar a cada personagem uma motivação pessoal, alinhando-se perfeitamente com o tema do Horror Pessoal.

Aqui estão três ganchos de trama distintos, um para cada jogador. A ideia é que você, como Mestre, possa entregar cada gancho individualmente a cada jogador antes do início da sessão, ou durante uma "cena de prólogo" para cada um. Eles todos convergem para o mesmo ponto: a convocação para encontrar o Senescal Marius Vinter.

---

### **Ganchos da Trama (Plot Hooks)**

Estes ganchos explicam por que os personagens, e não outros neonatos, foram escolhidos para esta missão delicada. Eles estabelecem dívidas, segredos e oportunidades que os ligam ao Senescal e à trama.

#### **Gancho 1: A Dívida**
*   **Para quem é:** O personagem com um senso de honra, lealdade ou que simplesmente está em uma posição fraca. Ideal para um personagem cujo Senhor é importante para ele.
*   **A Situação:** O Senhor (ou Criador) do seu personagem cometeu um erro grave no passado recente – uma quebra da Máscara que foi abafada, uma dívida de sangue com o vampiro errado, um insulto a um Ancião. Foi **Marius Vinter**, o Senescal, quem interveio e limpou a bagunça, colocando o Senhor do personagem em uma dívida imensa com ele. Agora, essa dívida está sendo cobrada.
*   **A Convocação:** O personagem recebe uma mensagem de seu Senhor, tensa e urgente. Ele explica (talvez não todos os detalhes sujos) que deve um favor inquestionável ao Senescal e que o personagem foi "oferecido" para quitá-lo. Recusar não é uma opção, pois isso significaria a destruição de seu Senhor e, por consequência, a sua própria. Você não está fazendo isso por Marius, está fazendo isso para salvar a pele de quem o criou.
*   **Tom da Convocação:** Coerção e lealdade forçada. A mensagem é clara: "Você *vai* fazer isso."

#### **Gancho 2: O Segredo**
*   **Para quem é:** O personagem com algo a esconder. Alguém que mantém um mortal importante por perto (um Touchstone) ou que tem um vício ou hábito que viola as Tradições.
*   **A Situação:** Seu personagem tem sido descuidado. Talvez ele tenha se apegado demais a um membro de sua família mortal, visitando-o com uma frequência perigosa. Ou talvez ele tenha um rebanho secreto que ninguém conhece, ou se alimenta de uma forma que a Princesa desaprovaria. Seja qual for o segredo, **Marius Vinter** descobriu. O Nosferatu sabe de tudo.
*   **A Convocação:** O personagem recebe uma mensagem anônima, contendo um único item que prova que seu segredo foi exposto: uma foto de seu Touchstone dormindo, tirada de dentro do quarto dele; um extrato bancário mostrando transferências para um contato que deveria ser secreto; um pequeno frasco com uma amostra do sangue de sua vítima favorita. Junto com o item, um endereço e um horário. Nenhuma ameaça explícita é necessária. A implicação é aterrorizante.
*   **Tom da Convocação:** Chantagem sutil e paranoia. A mensagem é: "Eu sei. Venha conversar."

#### **Gancho 3: A Oportunidade**
*   **Para quem é:** O personagem ambicioso, que anseia por status, poder e por deixar sua marca na sociedade da Camarilla.
*   **A Situação:** Desde seu Abraço, seu personagem tem se esforçado para ser notado. Ele frequenta o Elysium, cumpre as etiquetas, faz os contatos certos. Ele quer subir. Suas manobras, embora pequenas, não passaram despercebidas. **Marius Vinter** viu em você uma ferramenta útil: alguém com fome de poder, disposto a sujar as mãos para conseguir o que quer.
*   **A Convocação:** O personagem é abordado por um Carniçal bem-vestido em um local neutro. A mensagem é um convite, não uma ordem. O Senescal vê "potencial" em você e gostaria de oferecer uma "oportunidade única" para ganhar prestígio e o favor da elite da cidade. Esta é a sua chance de sair da mediocridade dos neonatos e entrar no jogo de verdade. A tarefa será perigosa, sim, mas a recompensa... a recompensa será o reconhecimento que você tanto busca.
*   **Tom da Convocação:** Tentação e ambição. A mensagem é: "Mostre-me do que você é capaz, e eu abrirei as portas para você."

---

**Unindo os Ganchos:**

Independentemente do gancho, todos os três personagens recebem a mesma instrução final: encontrar-se com o Senescal Marius Vinter em seu refúgio nos túneis de serviço sob o Jardim Botânico. A primeira cena da aventura será o encontro dos três, talvez na entrada dos túneis, cada um chegando por suas próprias razões terríveis, percebendo que não estão sozinhos nesta "missão". A desconfiança mútua já começará a se formar antes mesmo de receberem as instruções formais.

O que acha destes ganchos? Se estiverem bons, podemos prosseguir para o detalhamento dos **Personagens do Mestre (PdMs)** principais que os jogadores encontrarão: o próprio Senescal Marius Vinter e os três principais suspeitos e candidatos ao cargo de Primógeno.

---

## Ato1

Com certeza. Com base em nosso planejamento, aqui está o **Ato 1** da aventura, projetado para durar aproximadamente 60-90 minutos e mergulhar os jogadores diretamente na teia de intrigas de Curitiba.

---

### **Ato 1: O Chamado nas Sombras**

Este ato foca em reunir os personagens, apresentar o contratante, estabelecer a missão (oficial e secreta) e fornecer a primeira pista tangível para a investigação.

#### **Cena 1: Encontro no Jardim de Vidro**

**Local:** O Jardim Botânico de Curitiba, uma hora antes da meia-noite. A famosa estufa de vidro e metal está iluminada por dentro, mas o resto do parque está mergulhado em silêncio e escuridão, com a neblina fria da noite se acumulando no chão.

**Desenvolvimento:**
Guiados por suas motivações pessoais (a Dívida, o Segredo ou a Oportunidade), os três personagens são instruídos a ir até a estufa do Jardim Botânico e esperar por um contato. Eles chegam separadamente, encontrando um ao outro no silêncio opressivo do local.

*   **Atmosfera:** A cena deve ser carregada de paranoia. Eles não se conhecem. São aliados? Rivais? Uma armadilha? A estufa, um símbolo de beleza e vida durante o dia, agora parece uma jaula de vidro. O som de seus próprios passos no cascalho ecoa alto demais.
*   **Interação:** Este é o momento para os jogadores se apresentarem (ou não) e começarem a se avaliar. Quem são eles? Por que estão aqui? A desconfiança inicial é um elemento chave.
*   **O Contato:** O contato não é uma pessoa. É um **Carniçal** de aparência doentia e vestes de jardineiro que emerge das sombras. Ele não fala, apenas aponta para uma discreta grade de serviço escondida sob uma moita de arbustos bem podados. Com um rangido de metal, ele a abre, revelando uma escada escura que desce para as entranhas da terra. Ele gesticula para que entrem e, assim que o último personagem desce, a grade se fecha acima deles, mergulhando-os na escuridão total.

**Objetivo da Cena:** Reunir o grupo, estabelecer um tom de mistério e paranoia, e iniciar a transição do mundo superficial de Curitiba para o submundo secreto dos Amaldiçoados.

#### **Cena 2: Audiência com o Mestre das Aranhas**

**Local:** O refúgio do Senescal Marius Vinter. Não é um esgoto sujo, mas sim uma antiga central de controle do sistema de irrigação do Jardim Botânico. Monitores antigos piscam com dados de fluxo de água, mapas da cidade estão pregados nas paredes e o zumbido de servidores e ventiladores é constante. O cheiro é de ozônio, poeira e terra úmida.

**Desenvolvimento:**
Após uma breve caminhada pelos túneis de serviço de concreto, o Carniçal os deixa em frente a uma porta de aço. Ela se abre e eles entram no refúgio do Senescal. **Marius Vinter (Nosferatu)** não está escondido. Ele está sentado em uma cadeira de escritório puída em frente a um banco de monitores, observando-os chegar através de câmeras de segurança. Sua aparência é sutilmente perturbadora, com uma pele pálida e esticada sobre os ossos e olhos que não piscam.

*   **O Senescal:** Marius é direto e não perde tempo com formalidades. Ele se dirige a cada personagem individualmente, fazendo uma breve e cortante referência ao gancho que os trouxe ali, deixando claro que ele sabe exatamente com quem está falando e por que eles não podem recusar.
    *   *(Para o com a Dívida):* "Seu Senhor lhe manda lembranças. E paga suas contas."
    *   *(Para o com o Segredo):* "Gosto de manter meus jardins bem cuidados. E meus segredos bem guardados. Os seus inclusos, por enquanto."
    *   *(Para o com a Oportunidade):* "Você queria uma chance de provar seu valor. Não a desperdice."
*   **A Missão Dupla:** Marius explica a situação.
    1.  **A Missão Oficial:** "O Primógeno Valentin Dubois foi assassinado. A Princesa Isolde exige que o responsável seja encontrado e apresentado à justiça dela. Vocês, como rostos novos e insignificantes, podem fazer perguntas que outros não podem. Descubram quem o matou."
    2.  **A Missão Real:** Ele se inclina para frente, sua voz baixa e conspiratória. "A verdade é um luxo. O que eu preciso é de *controle*. Três candidatos já estão se movendo para tomar o lugar de Valentin. A investigação de vocês é a desculpa perfeita para se aproximarem deles. Vasculhem suas vidas, descubram seus vícios, suas fraquezas, os cadáveres que eles escondem. Entreguem-me a alavanca de que preciso para garantir que o *candidato certo* assuma o posto. A morte de Valentin é uma tragédia; uma sucessão descontrolada seria um desastre."

*   **A Recompensa e a Ameaça:** Marius promete recompensas adequadas a cada um deles (a dívida do Senhor perdoada, o segredo mantido a salvo, um favor significativo para sua ascensão) e deixa a ameaça implícita: falhar é o mesmo que recusar, e as consequências seriam... desagradáveis.

**Objetivo da Cena:** Apresentar o antagonista/patrono, estabelecer claramente os objetivos e as apostas da aventura, e forçar a cooperação entre os personagens.

#### **Cena 3: A Pista nas Cinzas**

**Desenvolvimento:**
Antes de dispensá-los, Marius entrega-lhes a primeira pista.
"Meus agentes recuperaram isto do refúgio de Valentin antes que a polícia mortal o lacrasse completamente."

Ele joga um pequeno pendrive de metal sobre a mesa.

*   **A Pista:** "A maior parte dos dados estava corrompida pelo... evento. Mas conseguimos extrair um arquivo: a agenda pessoal e criptografada de Valentin. Meus decifradores só conseguiram abrir um fragmento: seus três últimos compromissos na noite em que morreu."

Marius mostra em um de seus monitores a lista:
1.  **Isadora Alencar (Toreador):** Sua protegida e rival declarada. Encontro no "Ateliê de Valentin". Motivo: "Discussão de Patrocínio".
2.  **Lucian Furtado (Ventrue):** Um banqueiro de investimentos e tradicionalista da Camarilla que via Valentin como um dândi irresponsável. Encontro no "Clube Curitibano (Elysium)". Motivo: "Assuntos do Conselho".
3.  **"Oráculo" (Malkavian):** Um vidente recluso que Valentin consultava para inspiração artística e, dizem os boatos, para prever os movimentos de seus rivais. Encontro em seu refúgio, a "Livraria Secreta". Motivo: "Consulta".

*   **A Ordem:** "O ateliê de Valentin está sob o selo da Princesa, mas eu lhes concedo acesso por esta noite. Comecem por lá. Vejam o que os olhos mortais não viram. Quero um relatório antes do nascer do sol. Agora, saiam."

**Objetivo da Cena:** Fornecer aos jogadores um ponto de partida claro e três pistas diretas para investigar, dando-lhes agência sobre qual suspeito abordar primeiro após visitarem a cena do crime.

---

O Ato 1 termina com os personagens sendo escoltados para fora dos túneis, de volta à noite fria de Curitiba, com a localização da cena do crime, uma lista de três suspeitos poderosos e a pressão esmagadora do Senescal em suas costas. O que eles farão a seguir?

Se este ato estiver de acordo, podemos avançar para o **Ato 2: A Teia de Segredos**, detalhando a cena do crime e os três suspeitos.

---

## Npcs Principais

Excelente. A força de uma aventura de Vampiro reside em seus personagens. Um elenco bem construído de PdMs (Personagens do Mestre) é o que transformará esta investigação em uma teia de intrigas memorável.

Aqui estão os perfis dos NPCs principais, incluindo os suspeitos, o patrono e o verdadeiro vilão oculto.

---

### **NPCs Principais**

#### **O Patrono / Potencial Ameaça**

**Marius Vinter, o Senescal da Teia**
*   **Clã:** Nosferatu
*   **Aparência:** Marius não é um monstro grotesco de esgoto. Sua maldição se manifesta de uma forma mais sutil e perturbadora. Sua pele é completamente desprovida de pigmento e translúcida, com veias azuis visíveis por baixo. Seus olhos são grandes, negros e não piscam, e seus movimentos são econômicos e precisos, como os de uma aranha. Ele se veste com ternos funcionais e escuros, sempre impecáveis.
*   **Personalidade:** É a personificação do controle frio. Marius fala em um tom baixo e monocórdico, e sua maior arma é a informação. Ele vê a sociedade dos Amaldiçoados não como uma comunidade, mas como um sistema complexo de alavancas e engrenagens. Ele sabe que a informação correta, aplicada no ponto certo, pode mover montanhas ou destruir anciões. Ele despreza o caos e a paixão, vendo-os como falhas de design.
*   **Conexão com a Trama:** Ele é o cérebro por trás da missão dos personagens. Ele não se importa com a justiça pela morte de Valentin; ele se importa em manter a estabilidade do domínio e, mais importante, aumentar sua própria influência sobre a Princesa, garantindo que o próximo Primógeno lhe deva um favor. Ele é um **aliado de conveniência** que se tornará uma **ameaça mortal** se os personagens falharem ou se tornarem um risco para suas operações.

---

#### **Os Suspeitos / Peões**

**1. Isadora Alencar, a Musa Ambiciosa**
*   **Clã:** Toreador
*   **Aparência:** Uma beleza clássica e melancólica. Isadora tem longos cabelos escuros, olhos expressivos e se veste com um estilo *boho-chic* que parece ao mesmo tempo caro e sem esforço. Ela está sempre com uma expressão de dor artística no rosto, mas seus olhos traem uma ambição afiada.
*   **Personalidade:** Passional, intensa e dramaticamente volátil. Isadora foi a protegida de Valentin por décadas e sua maior rival. Ela o amava e o odiava na mesma medida. Ela acreditava que ele estava segurando sua carreira artística e política para que ela nunca o superasse. Seu álibi é fraco: ela admite ter discutido com ele na noite de sua morte, saindo furiosa de seu ateliê.
*   **Segredo (Alavanca de Marius):** Isadora sofre de um bloqueio criativo paralisante. Para se "inspirar", ela cultiva um mortal, um jovem poeta universitário, a quem ela está lentamente levando à loucura através de seu controle emocional e alimentação constante. Ela está viciada no desespero dele. Expor isso a destruiria socialmente.
*   **Potencial:** Pode ser uma **aliada relutante** se os jogadores a convencerem de que estão buscando o verdadeiro assassino de seu mentor. Ela sabe mais sobre a vida íntima de Valentin do que ninguém.

**2. Lucian Furtado, o Pilar Rachado**
*   **Clã:** Ventrue
*   **Aparência:** A imagem da autoridade corporativa. Lucian veste ternos caríssimos, tem um aperto de mão firme e um cabelo grisalho impecavelmente penteado. Ele exala um ar de superioridade e desprezo por tudo que considera frívolo.
*   **Personalidade:** Arrogante, conservador e obcecado pela Tradição da Camarilla. Ele via Valentin como um dândi decadente e uma influência perigosa no Conselho Primógeno, sempre defendendo causas "artísticas" em vez de focar na segurança e no lucro do domínio. Seu álibi é sólido: ele estava no Elysium, visto por dezenas de vampiros, mas deixou o local pouco antes da hora estimada da morte de Valentin.
*   **Segredo (Alavanca de Marius):** Lucian é um hipócrita. Ele prega a ordem e o controle, mas sua fortuna mortal está ruindo devido a investimentos de altíssimo risco que deram errado. Ele tem desviado discretamente fundos dos cofres comunais da Camarilla para cobrir suas perdas. Se isso for revelado, a Princesa o fará em pedaços.
*   **Potencial:** É o mais provável de ser um **antagonista direto** à investigação, vendo os personagens como insetos irritantes fuçando em seus negócios.

**3. "Oráculo", o Vidente Fragmentado**
*   **Clã:** Malkavian
*   **Aparência:** Oráculo é andrógino e atemporal. Eles usam roupas simples e escuras e raramente saem de sua livraria/refúgio. Seus olhos parecem ver através das pessoas, focando em algo que só eles podem perceber. Carregam consigo um baralho de tarô gasto e sujo.
*   **Personalidade:** Desconectado da realidade linear, Oráculo fala por enigmas e profecias fragmentadas que, muitas vezes, se provam assustadoramente precisas. Eles não se importam com a política da Camarilla, mas sim com os "padrões" e "ressonâncias" que os eventos causam na cidade. Valentin os visitava regularmente, buscando inspiração e conselhos.
*   **Segredo (Alavanca de Marius):** A insanidade de Oráculo tem um foco. Suas visões são mais claras e potentes quando eles estão perto de um objeto específico: um velho camafeu de prata com a imagem de uma mulher mortal. Este é seu último Touchstone, um elo com uma vida que eles não conseguem mais lembrar. Oráculo vive em terror constante de perdê-lo, pois acredita que sem ele, sua consciência se dissolveria completamente na Teia de Loucura (Cobweb).
*   **Potencial:** Uma **fonte de informação caótica**. Ele não dará respostas diretas, mas pode fornecer um vislumbre da verdade através de uma carta de tarô, um rabisco em um livro ou um sussurro enigmático.

---

### **O Verdadeiro Vilão**

**Helena, a Sombra Traída**
*   **Clã:** N/A (Carniçal)
*   **Aparência:** Uma mulher de meia-idade com uma aparência esquecível. Helena tem cabelos grisalhos presos em um coque apertado e usa roupas simples e funcionais. Seus olhos, no entanto, guardam uma chama de ressentimento que arde há cinquenta anos. Ela é a zeladora e assistente de longa data do ateliê de Valentin.
*   **Personalidade:** Servil, silenciosa e aparentemente leal até o fim. Helena é a definição da pessoa que ninguém nota. Ela está sempre no fundo, limpando um copo, arrumando uma tela, ouvindo tudo. Por baixo dessa fachada, existe uma alma corroída pelo ódio e pela promessa quebrada.
*   **Conexão com a Trama e Motivação:** Helena serviu Valentin por mais de meio século, amando-o com a devoção distorcida de um carniçal. Ele prometeu a ela o Abraço inúmeras vezes, mas sempre a preteriu por "musas" mais jovens e belas, como Isadora. Seu amor apodreceu e se transformou em um ódio obsessivo. Ela não queria apenas matá-lo; ela queria apagá-lo. Usando o conhecimento que adquiriu ao longo dos anos, ela fez contato com um Hécata (Clã da Morte) e trocou segredos valiosos de Valentin por um ritual de Oblívio. Na noite da morte, ela serviu a Valentin seu "vinho" favorito, que na verdade era um componente do ritual. O ritual usou a própria vitae de Valentin contra ele, desfazendo-o em cinzas de dentro para fora.
*   **Plano Atual:** Helena está "ajudando" na investigação, plantando pistas falsas que incriminam Isadora, a mulher que ela mais odeia por ter recebido o "presente" que deveria ser seu. Ela é a testemunha perfeita e o assassino invisível. O horror pessoal da história está nela: a tragédia de uma vida devotada que se tornou um instrumento de vingança.

---

## Ato2

Claro. O Ato 2 é o coração da nossa one-shot, onde a intriga se aprofunda e o perigo se torna real. Os jogadores passarão da teoria para a prática, mergulhando nas vidas noturnas dos suspeitos. Este ato é projetado para durar de 90 a 120 minutos.

---

### **Ato 2: A Teia de Segredos**

Com as ordens do Senescal e a primeira pista em mãos, os personagens iniciam sua investigação. Este ato é menos linear, permitindo que os jogadores escolham qual pista seguir primeiro. Cada caminho revelará parte da verdade, mas também os afundará mais na perigosa política de Curitiba.

#### **Cena 4: O Ateliê Silencioso**

**Local:** O refúgio de Valentin Dubois no bairro do Batel. Um loft de luxo, com pé-direito alto, grandes janelas que dão para a cidade e paredes cobertas por suas pinturas – retratos vibrantes e expressivos de mortais e vampiros.

**Desenvolvimento:**
O local foi "limpo" pelos agentes da Princesa, mas a atmosfera é pesada. O ar cheira a ozônio e a uma estranha secura. No centro da sala, um sofá de veludo caro tem uma silhueta humana marcada em cinzas finas e escuras.

*   **A Testemunha-Chave:** Ao chegarem, eles são recebidos por **Helena**, a Carniçal zeladora. Ela está quieta, eficiente e parece devastada pela perda de seu mestre. Ela se oferece para "ajudar", guiando-os pelo local. Helena é a assassina, e esta é sua chance de manipular a investigação desde o início. Ela responderá às perguntas com tristeza ensaiada, apontando detalhes que incriminem Isadora. "Ela e o Mestre tiveram uma briga terrível naquela noite... ela saiu batendo a porta. Pobre Mestre Valentin, ele só queria ajudá-la."

*   **Pistas a Serem Encontradas:**
    1.  **A Tela Rasgada (Pista para Isadora):** Em um canto, uma tela recém-pintada está caída no chão, rasgada com um único golpe violento. A pintura era um retrato de Isadora Alencar. Um teste de Raciocínio + Percepção pode notar pequenas gotas de vitae (sangue de vampiro) perto do rasgo, indicando uma fúria sobrenatural.
    2.  **A Carta de Ameaça (Pista para Lucian):** Em uma gaveta trancada da escrivaninha de Valentin (requer um teste de Destreza + Lábia para arrombar ou o uso de Disciplinas), os personagens encontram uma correspondência oficial do Primógeno Ventrue, Lucian Furtado. O tom é gélido e ameaçador, falando sobre a "irresponsabilidade fiscal" de Valentin e as "consequências severas" se ele não votasse a favor de uma proposta de Lucian no conselho.
    3.  **A Carta de Tarô (Pista para Oráculo):** Caída sob a mesa de centro, quase escondida pelas cinzas, está uma única carta de tarô: **A Torre**. A carta mostra uma torre sendo atingida por um raio, com figuras caindo dela. Simboliza desastre súbito, revelação e destruição de algo que se acreditava ser seguro.
    4.  **A Pista Sutil (Pista para Helena):** Um personagem com alta Percepção ou Auspícios pode notar algo estranho: ao lado da mancha de cinzas no sofá, há um único copo de cristal. Ele está perfeitamente limpo, sem impressões digitais, manchas ou resíduos. Quase como se alguém o tivesse limpado *depois* do ocorrido. Helena, se questionada, dirá que "tinha o hábito de sempre manter as coisas do Mestre impecáveis".

**Objetivo da Cena:** Apresentar a cena do crime, introduzir a vilã de forma disfarçada e fornecer pistas que levem aos três suspeitos, dando aos jogadores a liberdade de escolher seu próximo passo.

---

#### **Cenas 5, 6 e 7: Os Suspeitos (Podem ser feitas em qualquer ordem)**

**Cena 5: A Musa Ferida (Encontrando Isadora Alencar)**
*   **Local:** Um café 24h soturno e artístico na região de São Francisco, onde Isadora está sentada sozinha, bebendo um café que nunca esfria.
*   **Interação:** Isadora está em um estado de luto dramático, mas por baixo há uma camada de medo e ambição. Se abordada com cuidado, ela admitirá a briga com Valentin, alegando que ele era um mentor tirânico. Ela usará todo o seu carisma para pintar **Lucian Furtado** como o culpado mais provável. "Aquele Ventrue sem alma... ele odiava tudo o que Valentin representava. A paixão, a liberdade...". Com um teste bem-sucedido de Manipulação + Lábia (ou Intimidação), ela pode confessar que Valentin estava se tornando paranoico, visitando "aquele Malkaviano louco" com frequência, em busca de conselhos.

**Cena 6: A Fortaleza Corporativa (Encontrando Lucian Furtado)**
*   **Local:** O topo de um arranha-céu comercial no Centro Cívico. O escritório de Lucian é minimalista, frio e tem uma vista de poder sobre a cidade.
*   **Interação:** Lucian é arrogante e desdenhoso. Ele não tem tempo para "cães de recado neonatos". Ele confirmará a reunião com Valentin no Elysium, tratando-a como um negócio trivial. Ele tentará intimidar os personagens, talvez fazendo uma ligação velada ao Senhor de um deles. Ele culpará a "histeria emocional" de **Isadora**, chamando-a de "uma criança instável com presas". Um teste de Raciocínio + Finanças ou Investigação pode permitir que um personagem note relatórios financeiros abertos em seu computador, mostrando perdas massivas – um sinal de seu segredo e desespero.

**Cena 7: O Oráculo no Labirinto (Encontrando "Oráculo")**
*   **Local:** "A Livraria Secreta", um sebo empoeirado e labiríntico no centro da cidade. Os livros estão empilhados do chão ao teto, criando corredores claustrofóbicos.
*   **Interação:** Oráculo não responde a perguntas diretas. Eles se comunicam através dos livros e de seu baralho de tarô. Se os jogadores mostrarem a carta da Torre, Oráculo sorrirá. Eles podem oferecer uma "leitura" sobre a morte de Valentin. As cartas ou frases que eles dirão serão enigmáticas, mas conterão a verdade:
    *   (Sobre Isadora) "A Rainha de Copas chora com o coração partido, mas a adaga em sua mão é de madeira, não de aço." (Ela é emocional, mas não a assassina).
    *   (Sobre Lucian) "O Rei de Ouros está muito ocupado contando suas moedas que desaparecem para notar o incêndio no portão do castelo." (Ele está distraído por seus problemas financeiros).
    *   (A Pista Crucial) **"A Torre não foi derrubada por reis ou rainhas. Ela foi corroída por dentro, pela pedra esquecida em sua fundação. Cuidado com a lealdade que azedou como vinho. A serva se torna mestra quando o cálice está envenenado."**

---

#### **Complicação de Meio de Ato: O Aviso**

Depois que os jogadores investigarem pelo menos dois dos suspeitos, a verdadeira assassina, Helena, percebe que eles são mais competentes do que ela esperava. Ela decide enviar um aviso.

*   **O Evento:** Enquanto os personagens estão em seus refúgios durante o dia, ou se movendo pela cidade na noite seguinte, um deles é alvo de uma mensagem sutil e aterrorizante. Pode ser:
    *   Um rato morto deixado na soleira de um refúgio com uma única palavra escrita em um papel em sua boca: "PAREM".
    *   O Touchstone de um dos personagens recebe uma ligação anônima onde só se ouve uma respiração silenciosa.
    *   Um dos personagens sente que está sendo observado por uma figura perfeitamente comum e esquecível na multidão, que desaparece assim que é notada.

**Objetivo do Ato 2:** Permitir que os jogadores investiguem livremente, coletem informações conflitantes dos suspeitos, descubram seus segredos (as alavancas para Marius) e recebam a pista crucial que aponta para um culpado inesperado. A complicação final aumenta as apostas e deixa claro que eles estão lidando com um inimigo ativo e perigoso. O ato termina quando eles reúnem as pistas e percebem que a verdade é mais complicada do que parece.

---

## Locais

Com certeza. Dar vida aos locais é fundamental para criar a imersão. Cada cenário em Curitiba deve refletir a dualidade da cidade: a fachada ordeira e a podridão oculta por baixo.

Aqui estão os locais importantes para a nossa aventura, *Réquiem em Cinzas*.

---

### **Locais Importantes**

#### **1. O Jardim Botânico**
*   **Descrição:** O cartão-postal de Curitiba. Durante o dia, um paraíso de simetria e beleza natural. À noite, transforma-se em um lugar sinistro. A icônica estufa de vidro e metal, o "Palácio de Cristal", brilha com uma luz fantasmagórica, mas os jardins ao redor são um labirinto de sombras e silêncio. A neblina fria se arrasta pela grama perfeitamente aparada, e o som de passos no cascalho parece um trovão na quietude opressiva.
*   **Atmosfera:** Paranoia e beleza estéril. É um lugar onde a natureza foi domada e forçada a uma ordem rígida, muito parecido com a sociedade da Camarilla local. Os personagens se sentirão expostos sob o olhar de vidro da estufa, como insetos em um terrário.
*   **Papel na Trama:** O ponto de encontro inicial. É o portal entre o mundo mortal, superficial, e o submundo de túneis e segredos do Senescal Marius Vinter. A descida pela grade de serviço é uma metáfora literal da entrada dos personagens no verdadeiro jogo de poder.

#### **2. O Refúgio do Senescal (A Central de Controle)**
*   **Descrição:** Escondido nos túneis de serviço sob o Jardim Botânico, este não é um covil sujo. É uma antiga central de controle do sistema de irrigação do parque, reaproveitada por Marius. Paredes de concreto frio são cobertas por mapas da cidade, diagramas de encanamento e telas de computador. Monitores antigos, com letras verdes piscando, dividem espaço com telas de LCD de alta definição que mostram imagens de câmeras de segurança de toda Curitiba. O ar tem o cheiro metálico de ozônio e terra úmida, e um zumbido constante de servidores preenche o ambiente.
*   **Atmosfera:** Vigilância total e controle clínico. Os personagens terão a sensação inescapável de que cada centímetro do local foi projetado para observação. Não há conforto, apenas funcionalidade. É o centro da teia da aranha, um lugar onde a informação é a única moeda que importa.
*   **Papel na Trama:** O quartel-general da missão. É aqui que os personagens recebem suas ordens, entregam seus relatórios e são constantemente lembrados de quem está no comando. Os monitores podem, em um momento de distração, mostrar um feed de câmera próximo ao refúgio de um dos personagens ou de seu Touchstone, um lembrete sutil do alcance de Marius.

#### **3. O Ateliê de Valentin (A Cena do Crime)**
*   **Descrição:** Um loft de luxo no bairro nobre do Batel, com janelas que vão do chão ao teto oferecendo uma vista deslumbrante da cidade. O espaço é uma explosão de vida e paixão congelada no tempo. Telas enormes com pinturas a óleo vibrantes e expressivas estão por toda parte. Há móveis de design, garrafas de vinho caras (usadas para entreter convidados mortais) e uma coleção de esculturas. O cheiro de terebintina e óleo de linhaça ainda paira no ar, mas por baixo dele há um odor antinatural, seco e estéril – o cheiro de cinzas. O ponto focal macabro é um sofá de veludo com a silhueta de um homem perfeitamente desenhada em pó escuro.
*   **Atmosfera:** Tragédia e silêncio. É um lugar que grita a personalidade vibrante de seu antigo dono, tornando sua ausência ainda mais profunda. A arte nas paredes parece observar os personagens, como fantasmas das inspirações de Valentin. É um mausoléu de uma não-vida interrompida.
*   **Papel na Trama:** O local principal da investigação. Os personagens devem examinar cada detalhe para encontrar as pistas que os levarão aos suspeitos. É aqui que eles encontram Helena, a assassina, disfarçada de serva leal, tornando a interação no local tensa e cheia de ironia dramática.

#### **4. O Clube Curitibano (Elysium)**
*   **Descrição:** O mais tradicional e exclusivo clube social da cidade é o Elysium oficial do domínio. Os vampiros não usam os salões de festas principais, mas sim uma ala mais antiga e reservada conhecida como "Salão Dourado". O local é decorado com móveis de jacarandá, lustres de cristal e retratos a óleo de figuras históricas da cidade (alguns dos quais ainda frequentam o local). O ar é pesado com o peso da tradição e da etiqueta.
*   **Atmosfera:** Tensão social e formalidade opressora. Este não é um lugar para conversas casuais. Cada palavra é uma jogada política, cada olhar é uma avaliação. O silêncio é preenchido por julgamentos não ditos. Para neonatos, entrar no Elysium sem um convite direto é como entrar em uma jaula de leões usando um terno de carne. É o ápice da gaiola dourada que é Curitiba.
*   **Papel na Trama:** O centro nevrálgico da política da Camarilla. É aqui que os personagens podem confrontar Lucian Furtado, ouvir boatos sobre os outros suspeitos e sentir na pele a pressão da sociedade vampírica. Uma gafe aqui pode ter consequências mais rápidas e brutais do que uma briga de rua.

#### **5. A Livraria Secreta (O Covil do Oráculo)**
*   **Descrição:** Um sebo esquecido em uma rua estreita do centro histórico. Não há placa na porta, apenas uma pequena gravura de um uróboro. Por dentro, o lugar é um labirinto claustrofóbico de estantes de livros que vão do chão ao teto. A poeira dança nos poucos feixes de luz que entram pela janela suja. Os livros não estão organizados por gênero ou autor, mas por um sistema caótico que só faz sentido para seu dono. O cheiro é de papel velho, cola e algo mais... ozônio, como antes de uma tempestade.
*   **Atmosfera:** Mistério e desorientação. O lugar parece fora do tempo e do espaço. Os corredores estreitos e as pilhas instáveis de livros criam uma sensação de que as paredes podem se fechar a qualquer momento. É fácil se perder aqui, tanto física quanto mentalmente.
*   **Papel na Trama:** O local para obter informações crípticas e sobrenaturais. É o domínio do Malkavian "Oráculo". As respostas não serão diretas, mas podem ser encontradas em um verso de um livro aberto aleatoriamente, em uma carta de tarô ou em um sussurro que parece vir das próprias paredes. É um contraste direto com a lógica fria de Marius e a formalidade do Elysium.

---

## Desafios

Excelente. Os desafios são o motor da aventura, testando as capacidades, a moralidade e os nervos dos personagens. Em uma história de intriga e horror pessoal, os desafios mais impactantes raramente envolvem combate direto.

Aqui estão os principais desafios que os personagens enfrentarão em *Réquiem em Cinzas*, divididos por categoria.

---

### **Desafios**

#### **1. Desafios de Interação Social (O Campo de Batalha Principal)**

Onde a aventura será ganha ou perdida. Cada conversa é um duelo.

*   **A Audiência com o Senescal:** O primeiro desafio é sobreviver ao encontro com Marius Vinter. Ele já sabe as fraquezas dos personagens (os Ganchos da Trama). O desafio não é negociar, mas sim projetar competência sem parecer arrogante, e aceitar a missão sem parecer um peão fraco.
    *   **Mecânica:** Testes de **Compostura + Resolve** para não demonstrar medo ou hesitação. Uma falha pode fazer com que Marius aumente a pressão ou guarde a demonstração de fraqueza para usar contra o personagem mais tarde.

*   **Navegando a Dor de Isadora:** Isadora Alencar é uma tempestade de emoções. O desafio é separar seu luto genuíno de seu melodrama manipulador. Pressioná-la demais pode fazê-la se fechar ou explodir em fúria. Simpatia demais pode fazer com que ela tente usar os personagens para seus próprios fins.
    *   **Mecânica:** Requer **Manipulação + Lábia** para guiá-la ou **Percepção + Empatia** para ler suas verdadeiras intenções por baixo do drama.

*   **Quebrando a Muralha de Lucian:** Lucian Furtado é uma fortaleza de arrogância e poder. Ele vê os personagens como insetos. O desafio é extrair informações dele sem ser esmagado. A intimidação direta é inútil. Os jogadores precisarão usar de astúcia, apelar para seu ego, ou usar a formalidade da Camarilla a seu favor.
    *   **Mecânica:** Testes de **Inteligência + Etiqueta** para abordá-lo corretamente, ou **Manipulação + Persuasão** usando um argumento que apele à sua lógica fria (ex: "um sucessor instável seria ruim para os negócios"). Uma falha crítica aqui pode resultar em Lucian usando sua influência para dificultar a vida dos personagens.

*   **Confrontando Helena, a Testemunha:** O desafio mais sutil. Helena parece uma fonte de informação confiável e inofensiva. A dificuldade está em perceber as pequenas inconsistências em sua história, a forma como ela sutilmente direciona a culpa.
    *   **Mecânica:** Requer um teste disputado de **Raciocínio + Percepção** contra a **Manipulação + Lábia** de Helena para notar uma contradição. O uso de **Auspícios (Sentir o Invisível)** pode revelar que sua aura de tristeza é falsa, escondendo um ódio profundo.

#### **2. Desafios de Investigação e Quebra-Cabeças**

Onde as mentes dos jogadores são postas à prova.

*   **O Quebra-Cabeça das Cinzas:** A cena do crime no ateliê de Valentin foi projetada para confundir. As pistas apontam para todos os suspeitos. O verdadeiro quebra-cabeça é metajogo: perceber que as pistas são *perfeitas demais*. A tela rasgada, a carta ameaçadora, a carta de tarô... parece um roteiro. A verdadeira pista é o que está *errado*: o copo limpo, a ausência de qualquer sinal de resistência.
    *   **Mecânica:** Uma série de testes de **Inteligência + Investigação** para encontrar cada pista. Um sucesso crítico em um desses testes pode levar o personagem a questionar a natureza "conveniente" das evidências.

*   **Decifrando o Oráculo:** O Malkavian não dará respostas, mas sim metáforas. O desafio é interpretar suas profecias crípticas. A frase "A Torre não foi derrubada por reis ou rainhas. Ela foi corroída por dentro, pela pedra esquecida em sua fundação" é a chave. Os jogadores precisam conectar "pedra esquecida" e "fundação" a alguém que sempre esteve lá, mas nunca foi notado: Helena.
    *   **Mecânica:** Não é um teste de dados, mas um quebra-cabeça para os próprios jogadores. A dificuldade está em separar os avisos poéticos da loucura genuína.

#### **3. Desafios de Fome e Humanidade (O Horror Pessoal)**

Onde a luta interna dos personagens vem à tona.

*   **A Tentação no Elysium:** O Clube Curitibano não é frequentado apenas por vampiros. Carniçais e mortais influentes (e deliciosos) também circulam por lá. Para um neonato faminto, manter a compostura em um ambiente tão rico em vitae e com tantos anciões observando é um teste de fogo.
    *   **Mecânica:** Se um personagem estiver com Fome 4 ou mais, o Mestre pode pedir um teste de **Resolve + Compostura** para resistir a um frenesi de fome ao se aproximar de um mortal particularmente atraente. Falhar aqui seria uma catástrofe social.

*   **A Ameaça ao Touchstone:** O aviso enviado por Helena não é um ataque físico, mas psicológico. O desafio é como o personagem reage ao ver seu elo com a humanidade ser ameaçado. Eles se afastam para protegê-lo, arriscando perder sua própria sanidade? Ou se aproximam, colocando-o em perigo?
    *   **Mecânica:** A reação do jogador a esta ameaça pode gerar **Máculas** em sua Humanidade, especialmente se eles agirem de forma egoísta ou paranoica, prejudicando o relacionamento com seu Touchstone.

#### **4. Desafios Físicos e de Combate (O Último Recurso)**

Onde a violência é uma confissão de fracasso, com consequências brutais.

*   **Os Cães de Guarda de Lucian:** Se os personagens encurralarem Lucian Furtado ou tentarem invadir seu escritório, ele não sujará as mãos. Ele enviará seu segurança Carniçal, um ex-militar treinado e fortalecido com a vitae Ventrue. O desafio não é vencer uma luta honrada, mas **sobreviver e escapar**. Lutar no lobby de um prédio comercial é uma quebra massiva da Máscara.
    *   **Mecânica:** O Carniçal é forte e resistente. O objetivo dos personagens deve ser usar suas Disciplinas (ex: **Ofuscação** para desaparecer, **Rapidez** para fugir, **Dominação** para pará-lo) para neutralizar a ameaça sem uma luta prolongada.

*   **A Vingança da Serva (Confronto Final):** Encurralar Helena em seu pequeno quarto nos fundos do ateliê é o clímax potencial. Ela não é uma guerreira, mas é desesperada e conhece o ambiente. O desafio é capturá-la antes que ela possa destruir as evidências ou a si mesma. Ela pode quebrar frascos de solventes inflamáveis, tentar iniciar um incêndio para cobrir sua fuga, ou até mesmo tentar se jogar pela janela.
    *   **Mecânica:** É um "combate" dinâmico e ambiental. Requer testes de **Destreza + Briga** para contê-la, **Raciocínio + Prontidão** para reagir a suas ações desesperadas, e talvez um teste social final de **Manipulação + Intimidação** para fazê-la se render.

---

## Ato3

Excelente. O Ato 3 é o catalisador que transforma a investigação em uma corrida contra o tempo. É o momento em que as peças se encaixam de forma chocante, a ameaça se torna iminente e os jogadores são forçados a tomar uma decisão que definirá o final da história. Este ato deve ser curto, impactante e durar cerca de 30-45 minutos.

---

### **Ato 3: O Ponto de Virada**

Após a investigação nos locais e a interação com os suspeitos, os personagens têm em mãos as informações cruciais: os segredos dos três Primógenos em potencial e a profecia enigmática do Oráculo. Eles provavelmente estão se sentindo confiantes, acreditando que têm o controle da situação. Este ato irá arrancar esse controle de suas mãos.

#### **Cena 8: A Convocação da Princesa**

**Desenvolvimento:**
Independentemente de onde estejam ou o que estejam fazendo, os personagens recebem uma mensagem simultânea e impossível de ignorar. Não vem de Marius. Vem de um arauto da própria **Princesa Isolde Reichmann**. A mensagem é curta e gélida: *"A Princesa os aguarda. Elysium. Imediatamente."*

*   **A Tensão:** Esta convocação é uma mudança drástica. Eles estavam trabalhando para o Senescal nas sombras, mas agora estão sendo arrastados para a luz ofuscante do poder máximo. A viagem até o Clube Curitibano deve ser tensa. Eles falharam? Foram descobertos? Ou o jogo de Marius chegou ao seu clímax?

**Local:** O "Salão Dourado" no Clube Curitibano (Elysium). A atmosfera está diferente. Não há os sussurros e as intrigas de uma noite normal. O silêncio é pesado, quebrado apenas pelo crepitar de uma lareira. Os poucos vampiros presentes (incluindo Isadora, Lucian e outros membros da elite) estão em silêncio, de pé, evitando o contato visual. A **Princesa Isolde** está sentada em uma poltrona de encosto alto, parecendo um trono. Marius Vinter está de pé ao seu lado, nas sombras, com o rosto inexpressivo.

*   **A Revelação Chocante:** A Princesa Isolde dispensa formalidades. Sua voz é calma, mas carrega o peso de um século de comando.
    "Fui informada," ela começa, com um olhar que passa por cima dos personagens como se fossem poeira, "que a investigação sobre a morte do Primógeno Dubois foi concluída."
    Ela faz uma pausa, deixando o pânico se instalar.
    "O Senescal me trouxe a culpada. A Carniçal, Helena. Ela confessou seu crime passional e será devidamente... descartada."

    Marius dá um passo à frente. "Agradeço o serviço de vocês em distrair os alvos errados enquanto meus próprios agentes resolviam a questão. Seu papel foi pequeno, mas útil. Estão dispensados."

**O Ponto de Virada:** Este é o soco no estômago dos jogadores.
1.  **Eles Foram Usados:** Sua investigação nunca foi sobre encontrar o assassino. Foi uma cortina de fumaça, uma "distração", como Marius disse. Enquanto eles corriam atrás dos suspeitos, Marius conduziu sua própria operação silenciosa para encontrar o verdadeiro culpado.
2.  **Marius Tem Todo o Poder:** Ao entregar o assassino, Marius parece o herói. Mas ele não revelou a verdade publicamente. Ele agora possui os segredos comprometedores de Isadora e Lucian (e possivelmente Oráculo), informações que os personagens coletaram para ele. Ele tem a lealdade do futuro Primógeno no bolso, não importa quem seja escolhido. Ele venceu.
3.  **A Falsa Solução:** A história de "crime passional" é limpa, conveniente e, mais importante, *esconde a verdade perigosa*: que um mero Carniçal, com o conhecimento certo, pode destruir um Primógeno. Essa é uma verdade que abalaria a estrutura de poder da Camarilla, e Marius a enterrou.

#### **Cena 9: A Escolha no Corredor**

**Desenvolvimento:**
Enquanto os personagens, humilhados, são dispensados do Salão Dourado, eles veem algo que não deveriam. Em um corredor adjacente, dois Carniçais corpulentos da Princesa arrastam Helena. Ela não está se debatendo. Ela está com o rosto pálido de terror, olhando diretamente para os personagens. Seus lábios formam uma única palavra silenciosa: **"Oráculo"**.

*   **A Pista Final e a Crise de Decisão:** Neste momento, a profecia do Malkavian faz todo o sentido. Helena, a "pedra esquecida", é a culpada. Mas ela não está confessando por vontade própria. O olhar dela é um pedido de socorro. Ela está sendo usada como bode expiatório para fechar o caso. A palavra "Oráculo" é sua última cartada, uma tentativa desesperada de indicar que há mais na história, talvez que Oráculo sabe a verdade sobre como ela conseguiu o ritual.

**O Desafio e a Mudança de Dinâmica:**
A investigação acabou. A missão deles foi um sucesso técnico (eles deram a Marius as alavancas que ele queria) e um fracasso total (eles foram feitos de tolos). Agora eles têm uma escolha impossível, que deve ser feita *imediatamente*:

1.  **Aceitar a Derrota (O Caminho Seguro):** Podem ir para casa. Ficam com a recompensa prometida por Marius (a dívida paga, o segredo guardado, a promessa de favor). Eles sobrevivem, mas sabem que são apenas peões em um jogo muito maior. Eles entregam os segredos que coletaram e se tornam cúmplices do encobrimento.
2.  **Buscar a Verdade Completa (O Caminho Perigoso):** Podem ignorar a ordem de Marius e ir atrás da última pista: por que Helena mencionou o Oráculo? Isso significa desafiar diretamente o Senescal, um dos vampiros mais perigosos da cidade, que acabou de consolidar seu poder. Eles não têm mais nenhuma proteção.
3.  **Tentar Salvar Helena (O Caminho Suicida):** Podem tentar intervir e salvar a Carniçal dos guardas da Princesa. Isso seria um desafio aberto à autoridade da Princesa, um ato de traição que provavelmente terminaria com a destruição de todos eles.

**Objetivo do Ato 3:** Mudar o objetivo da aventura de "Quem é o culpado?" para "O que faremos com a verdade?". A dinâmica passa de uma investigação reativa para uma decisão proativa e perigosa. As ações dos jogadores a partir deste ponto determinarão diretamente qual dos possíveis clímax eles enfrentarão, colocando o controle da narrativa de volta em suas mãos, mas com apostas muito mais altas.

---

## Ato4

Perfeito. Chegamos ao ato final. O clímax é o ponto de ebulição onde as decisões dos jogadores, especialmente a escolha feita no final do Ato 3, culminam em uma resolução dramática e cheia de consequências.

Aqui estão os três possíveis clímax, um para cada caminho que os jogadores podem ter escolhido.

---

### **Ato 4: O Clímax**

A noite é longa e a madrugada se aproxima. As ações dos personagens os levaram a um ponto sem volta. O resultado desta noite definirá seus futuros – ou a falta deles – em Curitiba.

#### **Clímax A: Réquiem para um Peão**
*(Se os jogadores escolheram aceitar a derrota e entregar as informações a Marius)*

**Local:** O refúgio do Senescal, sob o Jardim Botânico.

**Desenvolvimento:**
Os personagens retornam ao covil de Marius. O ambiente está mais frio do que antes. O Nosferatu os aguarda, não em frente aos seus monitores, mas de pé no centro da sala. Ele ouve o relatório deles em silêncio, absorvendo cada segredo sujo que eles descobriram sobre Isadora e Lucian.

*   **O Confronto Moral:** Este clímax não é uma luta física, mas uma execução moral. Marius não zomba deles. Ele fala com a calma de um professor explicando uma dura lição.
    "Vocês fizeram bem," ele diz, sua voz sem emoção. "A verdade que vocês buscaram – um Carniçal que descobriu um ritual Hécata para apagar um Primógeno da existência – é perigosa. O pânico que isso causaria... a instabilidade... seria catastrófico. Minha solução, a mentira do 'crime passional', é um sacrifício necessário pela ordem. A Camarilla não é construída sobre a verdade, mas sobre a *crença* no poder."

*   **A Coleira de Ouro:** Marius cumpre sua parte no acordo, mas de uma forma que os acorrenta a ele.
    *   **Para o com a Dívida:** "A dívida de seu Senhor está paga. A mim. Agora ele me deve."
    *   **Para o com o Segredo:** "Seu segredo está seguro. É meu segredo agora. Lembre-se disso."
    *   **Para o com a Oportunidade:** "Sua lealdade foi notada. Haverá um lugar para você no novo arranjo de poder. Um lugar ao meu lado."

*   **Resolução:** Os personagens saem do refúgio com suas recompensas, mas o gosto é de cinzas. Eles sobreviveram, mas se tornaram engrenagens na máquina de Marius. Eles veem a cidade de Curitiba ao amanhecer, não mais como uma oportunidade, mas como a gaiola dourada que realmente é. Eles não são mais neonatos ingênuos; são sobreviventes cínicos. O horror pessoal é a compreensão de que, para sobreviver, eles venderam a própria alma e ajudaram a enterrar uma verdade terrível.

---

#### **Clímax B: A Última Profecia**
*(Se os jogadores escolheram buscar a verdade completa indo atrás do Oráculo)*

**Local:** A Livraria Secreta.

**Desenvolvimento:**
Os personagens correm para a livraria do Oráculo. O lugar está um caos. Livros jogados pelo chão, páginas arrancadas. O Oráculo está no meio do labirinto de estantes, tremendo, não de medo, mas de uma sobrecarga de visões. "Eles sabem! A teia grita! A Aranha está vindo consertar o fio que se soltou!" ele sibila.

*   **O Confronto Tenso:** Antes que possam obter uma resposta clara, a porta da livraria se abre. **Marius Vinter** entra. Sozinho. Ele não veio lutar. Ele veio "limpar a bagunça".
    "Eu subestimei sua curiosidade," diz Marius, sua calma tornando a cena ainda mais tensa. "Isto acaba agora. Entreguem-me o Malkaviano. Esqueçam o que acham que sabem. E talvez vocês vejam o próximo pôr do sol."

*   **A Verdadeira Arma:** A luta aqui é pela informação. O Oráculo, em seu pânico, revela a verdade em fragmentos: "Helena... ela não encontrou os Hécata. Eles a encontraram! Trocaram o segredo... o ritual... por um lugar na cidade! Eles estão aqui!". A verdade é que um grupo do Clã da Morte usou Helena para criar um vácuo de poder e se infiltrar no domínio.

*   **Resolução:** Os jogadores devem fazer uma escolha rápida.
    *   **Lutar:** Atacar um Senescal é suicídio. Marius não lutará de forma justa. Ele usará Disciplinas para incapacitar (Dominação, Ofuscação) e seus agentes Carniçais cercarão o prédio. A luta será desesperada e provavelmente terminará com a captura ou destruição dos personagens.
    *   **Negociar:** A nova informação muda o jogo. Os personagens podem tentar usar o segredo da infiltração Hécata como moeda de troca. Marius odeia o caos mais do que qualquer coisa, e um Clã rival operando em seu domínio é o caos supremo. Ele pode concordar com uma trégua desconfortável, forçando os personagens a ajudá-lo a caçar os Hécata em troca de suas vidas. A aventura termina não com uma resolução, mas com o início de uma guerra sombria e secreta.

---

#### **Clímax C: Fogo no Elysium**
*(Se os jogadores escolheram o caminho suicida de tentar salvar Helena)*

**Local:** Os corredores de serviço e os fundos do Clube Curitibano (Elysium).

**Desenvolvimento:**
Este é um clímax de ação e desespero. Os personagens atacam os dois Carniçais da Princesa para libertar Helena. A luta deve ser rápida, brutal e silenciosa. Usar armas de fogo ou Disciplinas chamativas aqui dentro é o fim.

*   **A Corrida Contra o Tempo:** Após incapacitarem os guardas, eles têm Helena, que está em estado de choque. O alarme silencioso já foi acionado. Eles têm minutos, talvez segundos, antes que o Xerife e seus cães de caça isolem o prédio. O desafio se torna uma fuga desesperada pelo Elysium. Eles precisam navegar pelos corredores de serviço, cozinhas, talvez até mesmo sair por uma janela, tudo isso enquanto o coração da sociedade da Camarilla entra em alerta máximo.

*   **Sem Lugar para se Esconder:** A cidade inteira se torna hostil. Seus refúgios não são seguros. Marius sabe onde eles moram. Os aliados de ontem são os inimigos de hoje. Helena, em seu terror, lhes implora para levá-la aos túneis, ao "único lugar onde a Aranha não tece".

*   **Resolução:** A aventura termina em uma perseguição frenética.
    *   **Sucesso:** Eles conseguem despistar os perseguidores e desaparecer nos esgotos ou túneis desconhecidos da cidade. Eles têm Helena, a testemunha viva que pode expor tudo, mas pagaram um preço terrível. Eles são oficialmente Anátemas. Uma Caçada de Sangue foi declarada contra eles. Sua existência em Curitiba se tornou uma luta noturna pela sobrevivência, caçados por toda a Camarilla.
    *   **Fracasso:** Eles são encurralados pelo Xerife nos jardins do Elysium ou em uma rua próxima. A ordem da Princesa é clara: sem prisioneiros. O clímax é uma luta final e desesperada contra forças esmagadoramente superiores. Eles caem sob as presas e garras da justiça da Camarilla, tornando-se uma nota de rodapé sangrenta na história do domínio – um conto de advertência para outros neonatos tolos o suficiente para desafiar o poder estabelecido.

---

## Ato5

Perfeitamente. O Ato 5 é o epílogo, o momento de respirar após a tensão do clímax e contemplar as cicatrizes da noite. Ele solidifica as consequências das escolhas dos jogadores e estabelece o novo status quo para seus personagens, deixando um impacto duradouro.

Aqui está a resolução para cada um dos possíveis clímax.

---

### **Ato 5: A Resolução (Epílogo)**

A noite termina. O sol cruel de Curitiba sobe no horizonte, forçando os Amaldiçoados a seus refúgios. A cidade mortal acorda, alheia à guerra de sombras que foi travada. Para os personagens, no entanto, nada será como antes. O que eles encontram não é o descanso, mas as consequências de suas ações.

#### **Resolução A: A Gaiola Dourada**
*(Se os jogadores aceitaram seu papel e se aliaram a Marius)*

*   **O Novo Status Quo:** Os personagens sobreviveram e, aos olhos da Camarilla, tiveram sucesso. Eles são os neonatos que "ajudaram" a resolver o assassinato do Primógeno. Contudo, eles sabem a verdade: são propriedade de Marius Vinter. Sua liberdade é uma ilusão, e a segurança que ganharam é o metal frio de uma coleira.

*   **Destino dos NPCs:**
    *   **Marius Vinter:** Consolida seu poder como nunca antes. Ele usa a chantagem contra Lucian Furtado para forçá-lo a retirar sua candidatura, abrindo caminho para **Isadora Alencar**, que agora lhe deve um favor imenso, se tornar a nova Primogênita Toreador. Ele controla o Senescal, a Primogênita e a oposição.
    *   **Helena:** Desaparece. Marius provavelmente a "aposentou" em um refúgio isolado, mantendo-a viva como um seguro, ou simplesmente a destruiu para eliminar a última ponta solta. Ela se torna um fantasma, uma história que nunca aconteceu.
    *   **A Princesa Isolde:** Fica satisfeita com a resolução rápida e eficiente, cega (ou escolhendo ser cega) para a teia de controle que seu Senescal teceu sob seu nariz.

*   **Consequências para os Personagens:**
    *   A **Dívida** foi paga, mas agora o personagem e seu Senhor devem um favor e lealdade inquestionáveis a Marius.
    *   O **Segredo** está seguro, mas é uma arma que Marius não hesitará em usar se o personagem sair da linha.
    *   A **Oportunidade** se materializa. O personagem ambicioso recebe status, um pequeno domínio de caça ou um cargo menor. Ele está subindo, mas como um fantoche na mão do mestre.
    O horror pessoal é a sufocante falta de agência. Eles venceram o jogo, apenas para descobrir que agora são peças permanentes no tabuleiro de outra pessoa.

*   **Ganchos para o Futuro:** Marius os convocará novamente. A próxima tarefa pode ser ainda mais suja. Eles tentarão encontrar uma maneira de se libertar de sua influência ou se afundarão ainda mais em seu serviço?

---

#### **Resolução B: A Guerra nas Sombras**
*(Se os jogadores descobriram sobre os Hécata e formaram uma trégua com Marius)*

*   **O Novo Status Quo:** A investigação sobre a morte de Valentin tornou-se irrelevante. Os personagens são agora os únicos, além de Marius, que conhecem a ameaça existencial que se infiltrou em Curitiba. Eles não são mais simples neonatos; são agentes secretos em uma guerra fria contra o Clã da Morte.

*   **Destino dos NPCs:**
    *   **Marius Vinter:** É forçado a uma aliança desconfortável. Ele despreza a necessidade de confiar nos personagens, mas reconhece sua utilidade. Sua prioridade máxima muda da política interna para a segurança externa.
    *   **Helena:** Provavelmente é eliminada por Marius o mais rápido possível. Ela é uma ligação direta com os Hécata e um risco de segurança inaceitável.
    *   **Oráculo:** Torna-se um "recurso estratégico" vital, mas instável. Marius tentará controlá-lo, enquanto os personagens podem vê-lo como seu único aliado verdadeiro.

*   **Consequências para os Personagens:**
    Seus problemas pessoais foram eclipsados por uma ameaça muito maior. Eles vivem em um estado de paranoia constante, vendo sinais da presença Hécata em todos os lugares. Eles são forçados a aprimorar suas habilidades de espionagem, subterfúgio e combate, sabendo que um erro não significa uma reprimenda da Princesa, mas o esquecimento nas mãos dos necromantes. O horror pessoal é o conhecimento de que o monstro que eles conhecem (a Camarilla) é preferível ao monstro que se esconde nas sombras, e eles estão presos no meio.

*   **Ganchos para o Futuro:** A one-shot se transforma em uma crônica de espionagem e terror. A primeira missão de Marius: "Valentin tinha contatos. Descubram quais deles eram, na verdade, os coveiros. E eliminem-nos."

---

#### **Resolução C: Caçados ao Amanhecer**
*(Se os jogadores salvaram Helena e se tornaram fugitivos)*

*   **O Novo Status Quo:** Anátemas. A Camarilla inteira de Curitiba os quer mortos. Uma Caçada de Sangue foi declarada. Seus nomes foram sussurrados para todos os Amaldiçoados da cidade. Não há refúgio seguro, não há aliado, não há amanhã garantido. Eles são ratos correndo nos esgotos, com os cães de caça logo atrás.

*   **Destino dos NPCs:**
    *   **Marius Vinter:** Usa a "traição" dos personagens para justificar medidas de segurança ainda mais rígidas, aumentando seu controle sobre a cidade. Ele lidera pessoalmente a caçada, não por dever, mas para eliminar as testemunhas de sua manipulação.
    *   **Helena:** É o bem mais valioso e o maior fardo dos personagens. Ela conhece segredos que poderiam abalar o domínio, mas sua presença mortal os atrasa e os coloca em risco constante. Protegê-la se torna um teste diário de sua Humanidade.
    *   **Os Antigos Senhores:** Deserdam os personagens publicamente para salvar a própria pele. Qualquer amigo ou contato que eles tinham agora os evitará ou tentará entregá-los pela recompensa.

*   **Consequências para os Personagens:**
    A luta não é mais por status ou poder, mas pela sobrevivência nua e crua. Eles são forçados a abandonar seus refúgios, seus Touchstones (para protegê-los) e qualquer vestígio de suas antigas não-vidas. A Fome se torna uma companheira constante. O horror pessoal é a perda total de tudo. Eles fizeram a coisa "certa" ou "heroica", e o universo os puniu por isso da forma mais brutal possível.

*   **Ganchos para o Futuro:** A aventura se torna uma crônica de fuga. Conseguirão escapar de Curitiba? Tentarão chegar a um domínio Anarca próximo em busca de asilo? Ou ousarão usar as informações de Helena para tentar um contra-ataque desesperado, expondo Marius antes que ele os destrua?

---

## Resumo

Com certeza. Aqui está um resumo conciso de toda a aventura *Réquiem em Cinzas* que construímos, organizando os pontos principais para uma visão geral clara.

---

### **Resumo da Aventura: Réquiem em Cinzas**

#### **1. Conceito Central**
Uma aventura one-shot de horror pessoal e intriga política para **Vampiro: A Máscara 5e**. Três neonatos são recrutados para investigar o assassinato de um Primógeno em Curitiba, apenas para descobrirem que são meros peões em um jogo de poder muito maior, orquestrado pelo Senescal da cidade para consolidar seu controle.

#### **2. Parâmetros**
*   **Sistema:** Vampiro: A Máscara 5ª Edição
*   **Gênero:** Horror Pessoal e Intriga Política
*   **Jogadores:** 3 Neonatos
*   **Duração:** ~4 horas

#### **3. Contexto e Sinopse**
*   **Cenário:** A cidade fria e rigidamente controlada de Curitiba, um domínio da Camarilla governado pela Princesa Isolde Reichmann.
*   **Incidente:** O Primógeno Toreador, Valentin Dubois, é encontrado misteriosamente reduzido a cinzas, criando um vácuo de poder.
*   **Missão:** Os personagens são contratados pelo Senescal Nosferatu, **Marius Vinter**. A tarefa oficial é encontrar o assassino. A tarefa real é investigar os três principais candidatos ao cargo vago para que Marius possa chantageá-los e controlar o sucessor.

#### **4. Personagens Principais**
*   **O Patrono:** **Marius Vinter (Nosferatu)**, o Senescal mestre das informações e manipulador.
*   **Os Suspeitos:**
    1.  **Isadora Alencar (Toreador):** A protegida ambiciosa e rival de Valentin.
    2.  **Lucian Furtado (Ventrue):** O tradicionalista arrogante que desprezava Valentin.
    3.  **"Oráculo" (Malkavian):** O vidente enigmático que aconselhava a vítima.
*   **A Vilã Oculta:** **Helena (Carniçal)**, a leal e invisível assistente de Valentin, que o assassinou por vingança após uma promessa de Abraço quebrada por décadas.

#### **5. Estrutura da Aventura em Atos**

*   **Ato 1: A Introdução**
    *   Os personagens são convocados por Marius através de ganchos pessoais (Dívida, Segredo, Oportunidade).
    *   Encontram-se no Jardim Botânico e são levados ao refúgio do Senescal.
    *   Recebem a missão dupla e a primeira pista: a agenda de Valentin com seus três últimos encontros.

*   **Ato 2: A Complicação**
    *   Os jogadores investigam a cena do crime (o ateliê de Valentin), encontrando pistas que apontam para todos os suspeitos.
    *   Eles interrogam Isadora, Lucian e o Oráculo, descobrindo seus segredos (as "alavancas" para Marius) e recebendo uma profecia críptica que sugere um culpado inesperado ("a pedra esquecida na fundação").

*   **Ato 3: O Ponto de Virada**
    *   Os personagens são convocados ao Elysium pela Princesa.
    *   Marius Vinter revela que já "solucionou" o caso, apresentando Helena como a culpada e confessando que a investigação dos jogadores foi apenas uma distração.
    *   Os jogadores percebem que foram usados. Ao serem dispensados, veem Helena sendo levada, e ela lhes dá uma pista final silenciosa.
    *   **A Escolha Crucial:** Eles devem decidir entre aceitar sua condição de peões, investigar a última pista ou tentar uma intervenção suicida.

*   **Ato 4: O Clímax (Ramificado)**
    1.  **Caminho 1 (Aceitar):** Um confronto moral com Marius. Eles se tornam seus ativos, entregando as informações e cimentando o poder dele.
    2.  **Caminho 2 (Investigar):** Um confronto tenso com Marius no refúgio do Oráculo, onde descobrem uma conspiração maior do clã Hécata.
    3.  **Caminho 3 (Intervir):** Uma luta desesperada e uma fuga pelo Elysium, tornando-se Anátemas e sendo caçados pela cidade inteira.

*   **Ato 5: A Resolução (Consequências)**
    1.  **A Gaiola Dourada:** Os personagens sobrevivem com recompensas, mas estão acorrentados a Marius como suas ferramentas de confiança.
    2.  **A Guerra nas Sombras:** Eles formam uma aliança instável com Marius para combater a infiltração Hécata em Curitiba.
    3.  **Caçados ao Amanhecer:** Eles se tornam fugitivos, com uma Caçada de Sangue declarada contra eles, lutando pela sobrevivência noite após noite.

---

